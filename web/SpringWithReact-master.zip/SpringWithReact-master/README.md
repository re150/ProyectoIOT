# SpringWithReact
Simple react page to connect with spring back-end

# How to install
1. git clone <url>
2. (In terminal) cd (route to project)
3. yarn install
